"""
Streamlit frontend for PID Auto-Tuning Agent 
Run: streamlit run app.py
"""

import streamlit as st
import matplotlib.image as mpimg
import os
import time

from agent_tuner import tune_pid, get_specs_text

# ============================================================
# 页面配置
# ============================================================
st.set_page_config(
    page_title="PID Auto-Tuning Agent",
    page_icon="🎛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================
# 自定义 CSS 美化
# ============================================================
st.markdown("""
<style>
    /* 主标题样式 */
    .main-title {
        text-align: center;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 3rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }
    
    /* 副标题样式 */
    .sub-title {
        text-align: center;
        color: #666;
        font-size: 1.1rem;
        margin-bottom: 2rem;
    }
    
    /* 卡片样式 */
    .custom-card {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        border-radius: 20px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    
    /* 指标卡片样式 */
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 15px;
        padding: 1rem;
        text-align: center;
        color: white;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        margin: 0.5rem 0;
    }
    
    .metric-value {
        font-size: 1.8rem;
        font-weight: bold;
        margin: 0.5rem 0;
    }
    
    .metric-label {
        font-size: 0.8rem;
        opacity: 0.9;
    }
    
    /* 成功消息框 */
    .success-box {
        background: linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%);
        border-radius: 15px;
        padding: 1rem;
        text-align: center;
        font-weight: bold;
        margin: 1rem 0;
    }
    
    /* 警告消息框 */
    .warning-box {
        background: linear-gradient(135deg, #fda085 0%, #f6d365 100%);
        border-radius: 15px;
        padding: 1rem;
        text-align: center;
        font-weight: bold;
        margin: 1rem 0;
    }
    
    /* 错误消息框 */
    .error-box {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        border-radius: 15px;
        padding: 1rem;
        text-align: center;
        font-weight: bold;
        margin: 1rem 0;
        color: white;
    }
    
    /* 侧边栏美化 */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
    }
    
    [data-testid="stSidebar"] .stMarkdown, 
    [data-testid="stSidebar"] .stSelectbox label,
    [data-testid="stSidebar"] .stNumberInput label {
        color: white !important;
    }
    
    /* 侧边栏 info 框文字颜色（高对比度） */
    [data-testid="stSidebar"] .stAlert {
        background-color: #1a1a2e !important;
        color: #ffffff !important;
    }
    
    [data-testid="stSidebar"] .stAlert p {
        color: #ffffff !important;
        font-weight: 500 !important;
    }
    
    /* 按钮美化 */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 25px;
        padding: 0.6rem 2rem;
        font-size: 1.1rem;
        font-weight: bold;
        transition: all 0.3s ease;
        width: 100%;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    
    /* 参数卡片 */
    .param-card {
        background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
        border-radius: 15px;
        padding: 1rem;
        text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    /* 规格显示框（高对比度） */
    .specs-box {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border-radius: 15px;
        padding: 1rem;
        margin: 0.5rem 0;
        border-left: 4px solid #667eea;
        color: #ffffff;
    }
    
    .specs-box p {
        color: #ffffff !important;
        font-size: 0.9rem;
        margin: 0;
    }
    
    /* LaTeX 公式样式 */
    .latex-metric {
        font-family: monospace;
        font-size: 0.85rem;
        background: rgba(255,255,255,0.2);
        padding: 0.2rem 0.4rem;
        border-radius: 6px;
        display: inline-block;
    }
    
    /* 进度条美化 */
    .stProgress > div > div {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    }
</style>
""", unsafe_allow_html=True)


# ============================================================
# 辅助函数：将指标名称转换为 MathJax 格式（Streamlit 兼容）
# ============================================================
def format_metric_name(name):
    """将指标名称转换为 MathJax 格式，Streamlit 原生支持"""
    latex_names = {
        'overshoot': r'$\text{OS}$ 超调量',
        'tr': r'$t_r$ 上升时间',
        'ts': r'$t_s$ 稳定时间',
        'e_ss_ramp': r'$e_{ss,ramp}$ 斜坡稳态误差',
        'e_ss_acc': r'$e_{ss,acc}$ 加速度稳态误差',
        'phase_margin': r'$\text{PM}$ 相位裕度',
        'Mr': r'$M_r$ 谐振峰值',
        'BW': r'$\text{BW}$ 带宽',
        'settling_time': r'$t_s$ 稳定时间',
        'rise_time': r'$t_r$ 上升时间',
        'peak': r'$M_p$ 峰值'
    }
    return latex_names.get(name, name)


# ============================================================
# 标题区域
# ============================================================
st.markdown('<p class="main-title">🎛️ PID Auto-Tuning Agent</p>', unsafe_allow_html=True)
st.markdown('<p class="sub-title">基于 DeepSeek LLM 的智能 PID 参数自动整定系统</p>', unsafe_allow_html=True)

# ============================================================
# 侧边栏：问题选择
# ============================================================
with st.sidebar:
    st.markdown("## 📋 问题配置")
    st.markdown("---")
    
    problem = st.selectbox(
        "🎯 选择控制器类型",
        options=['a', 'b', 'c', 'd'],
        format_func=lambda x: {
            'a': '🎮 PD Controller (Kp=1 固定，调 Kd)',
            'b': '⚙️ PI Controller (调 Kp, Ki)',
            'c': '🔧 PID Controller (时域规格)',
            'd': '📊 PID Controller (频域规格)'
        }[x]
    )
    
    st.markdown("---")
    st.markdown("### 📊 性能指标要求")
    
    # 获取规格文本并美化显示（高对比度）
    specs_text = get_specs_text(problem)
    st.markdown(f"""
    <div class="specs-box">
        <p>🎯 {specs_text}</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("---")
    max_iter = st.number_input(
        "🔄 最大迭代次数",
        value=12,
        min_value=1,
        max_value=30,
        help="超过此次数仍未达标则停止"
    )
    
    st.markdown("---")
    st.markdown(f"**📌 当前配置**")
    st.markdown(f"- 问题类型: **{problem.upper()}**")
    st.markdown(f"- 最大迭代: **{max_iter}**")
    
    st.markdown("---")
    st.markdown("### ℹ️ 说明")
    st.caption("本系统使用 DeepSeek LLM 自动整定 PID 参数，通过迭代优化满足性能指标要求。")

# ============================================================
# 主区域：运行按钮
# ============================================================
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    run_button = st.button("🚀 开始智能调参", type="primary", use_container_width=True)

if run_button:
    
    start_time = time.time()
    
    try:
        # 使用 with 语句和 spinner 替代复杂的进度条动画
        with st.spinner('🤖 Agent 正在运行中，正在进行智能参数优化...'):
            result = tune_pid(problem=problem, max_iter=max_iter, verbose=False)
        
        elapsed_time = time.time() - start_time
        
        if result['success']:
            st.markdown(f"""
            <div class="success-box">
                ✅ 调参成功！ 🎉<br>
                耗时 {elapsed_time:.1f} 秒，在 {max_iter} 次迭代内找到满足要求的参数
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div class="warning-box">
                ⚠️ 未能在 {max_iter} 次迭代内达标<br>
                耗时 {elapsed_time:.1f} 秒，建议增加迭代次数或放宽要求
            </div>
            """, unsafe_allow_html=True)
        
        # 最优参数
        st.markdown("## 📊 最优参数")
        best_params = result['best_params']
        
        if problem == 'a':
            cols = st.columns([1, 1, 1])
            with cols[1]:
                st.markdown(f"""
                <div class="param-card">
                    <h3>🎯 Kd (最优)</h3>
                    <p style="font-size: 2rem; font-weight: bold; margin: 0;">{best_params[0]:.6f}</p>
                </div>
                """, unsafe_allow_html=True)
        elif problem == 'b':
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"""
                <div class="param-card">
                    <h3>🎯 Kp (最优)</h3>
                    <p style="font-size: 1.8rem; font-weight: bold; margin: 0;">{best_params[0]:.6f}</p>
                </div>
                """, unsafe_allow_html=True)
            with col2:
                st.markdown(f"""
                <div class="param-card">
                    <h3>🎯 Ki (最优)</h3>
                    <p style="font-size: 1.8rem; font-weight: bold; margin: 0;">{best_params[1]:.6f}</p>
                </div>
                """, unsafe_allow_html=True)
        else:
            col1, col2, col3 = st.columns(3)
            with col1:
                st.markdown(f"""
                <div class="param-card">
                    <h3>🎯 Kp</h3>
                    <p style="font-size: 1.5rem; font-weight: bold; margin: 0;">{best_params[0]:.6f}</p>
                </div>
                """, unsafe_allow_html=True)
            with col2:
                st.markdown(f"""
                <div class="param-card">
                    <h3>🎯 Ki</h3>
                    <p style="font-size: 1.5rem; font-weight: bold; margin: 0;">{best_params[1]:.6f}</p>
                </div>
                """, unsafe_allow_html=True)
            with col3:
                st.markdown(f"""
                <div class="param-card">
                    <h3>🎯 Kd</h3>
                    <p style="font-size: 1.5rem; font-weight: bold; margin: 0;">{best_params[2]:.6f}</p>
                </div>
                """, unsafe_allow_html=True)
        
        # 最终性能指标（使用 MathJax 格式）
        st.markdown("## 📈 最终性能指标")
        best_metrics = result['best_metrics']
        
        metrics_items = list(best_metrics.items())
        
        # 使用响应式列数
        num_cols = min(len(metrics_items), 4)
        cols = st.columns(num_cols)
        
        for idx, (k, v) in enumerate(metrics_items):
            col_idx = idx % num_cols
            with cols[col_idx]:
                if isinstance(v, (int, float)):
                    st.metric(
                        label=format_metric_name(k),
                        value=f"{v:.6f}"
                    )
                else:
                    st.metric(
                        label=format_metric_name(k),
                        value=str(v)
                    )
        
        # 最终响应曲线
        if result['figures'].get('final_response'):
            final_fig_path = result['figures']['final_response']
            if os.path.exists(final_fig_path):
                st.markdown("## 📉 最终响应曲线")
                try:
                    img = mpimg.imread(final_fig_path)
                    st.image(img, use_container_width=True, caption="阶跃响应曲线")
                except Exception as e:
                    st.info(f"无法加载响应图: {e}")
            else:
                st.info("响应图文件未找到")
        
        # 运行统计
        st.markdown("---")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("⏱️ 运行时间", f"{elapsed_time:.1f} 秒")
        with col2:
            st.metric("🔄 迭代次数", max_iter)
        with col3:
            st.metric("🎯 达标状态", "✅ 达标" if result['success'] else "❌ 未达标")
        
    except Exception as e:
        st.markdown(f"""
        <div class="error-box">
            ❌ Agent 运行出错<br>
            {str(e)}
        </div>
        """, unsafe_allow_html=True)

# ============================================================
# 页脚
# ============================================================
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #888; padding: 1rem;">
    <p>Powered by DeepSeek LLM | 基于上海交大 API | PID Auto-Tuning Agent</p>
    <p style="font-size: 0.8rem;">🤖 智能控制系统参数优化平台</p>
</div>
""", unsafe_allow_html=True)