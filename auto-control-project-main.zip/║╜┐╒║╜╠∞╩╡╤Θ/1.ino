// Linear Inverted Pendulum - 200Hz Fixed Version
// Timer2 CTC mode: (78+1)*1024/16MHz = 5.056ms ~= 200Hz
// No external libraries, native Arduino only

#define PWM 9
#define IN1 10
#define IN2 11
#define ENC_A 2
#define ENC_B 4
#define ZHONGZHI 800
#define POS_INIT 10000

#define KEY_MENU 3
#define KEY_S 15
#define KEY_MINUS 16
#define KEY_PLUS 17
#define KEY_X 18

volatile float Position = POS_INIT;
volatile float Sensor = 0;
volatile float Motor = 0;
float Balance_Pwm = 0, Position_Pwm = 0;
int Target = POS_INIT;
volatile unsigned char Flag_stop = 1;
float Balance_KP = 230, Balance_KD = 210, Position_KP = 40, Position_KD = 0;   // 加入位置环, 让小车自动回中避免撞墙
float Menu = 1, Amp1 = 5, Amp2 = 5, Amp3 = 5, Amp4 = 5;   // 按键步长加大, 调参更快

float Balance_Control(float s)
{
  static float LastBias = 0;
  float Bias = s - ZHONGZHI;
  float D = Bias - LastBias;
  LastBias = Bias;
  return Balance_KP / 10.0 * Bias + D * Balance_KD / 1000.0;
}

float Position_Control(int enc)
{
  static float LastPos = 0, Filtered = 0;
  float diff = enc - Target;
  Filtered = Filtered * 0.8 + diff * 0.2;
  float D = Filtered - LastPos;
  LastPos = Filtered;
  return Filtered * Position_KP / 1000.0 + D * Position_KD / 10.0;
}

void SetMotor(int m)
{
  // 若实测发现摆杆往左倒、小车却往右跑(越推越倒), 说明电机方向反了:
  // 把下面两行的 HIGH/LOW 对调即可
  if (m < 0) { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW); }
  else { digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH); }
  analogWrite(PWM, abs(m) + 10);
}

unsigned int ReadADC(unsigned char ch, unsigned char n)
{
  unsigned int v = 0;
  for (unsigned char i = 0; i < n; i++) v += analogRead(ch);
  return v / n;
}

// 5.056ms timer interrupt ~= 200Hz (balance loop), position loop divided by 5 = 40Hz
ISR(TIMER2_COMPA_vect)
{
  static unsigned char posCnt = 0;
  Sensor = ReadADC(5, 5);
  Balance_Pwm = Balance_Control(Sensor);
  if (++posCnt >= 5) {
    Position_Pwm = Position_Control((int)Position);
    posCnt = 0;
  }
  Motor = Balance_Pwm - Position_Pwm;
  if (Motor > 245) Motor = 245;
  if (Motor < -245) Motor = -245;
  if (Sensor < (ZHONGZHI - 200) || Sensor > (ZHONGZHI + 200) || Flag_stop == 1) {
    Flag_stop = 1;
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);
  } else {
    SetMotor((int)Motor);
  }
}

void READ_ENC_A()
{
  if (digitalRead(ENC_A) == HIGH)
  { if (digitalRead(ENC_B) == LOW) Position++; else Position--; }
  else
  { if (digitalRead(ENC_B) == LOW) Position--; else Position++; }
}

unsigned char MyClick(void)
{
  static unsigned char flag = 1;
  if (flag && (digitalRead(KEY_MENU) == 0 || digitalRead(KEY_S) == 0 ||
               digitalRead(KEY_MINUS) == 0 || digitalRead(KEY_PLUS) == 0))
  {
    flag = 0;
    if (digitalRead(KEY_MENU) == 0) return 1;
    if (digitalRead(KEY_S) == 0) return 2;
    if (digitalRead(KEY_MINUS) == 0) return 3;
    if (digitalRead(KEY_PLUS) == 0) return 4;
  }
  else if (digitalRead(KEY_MENU) == 1 && digitalRead(KEY_S) == 1 &&
           digitalRead(KEY_MINUS) == 1 && digitalRead(KEY_PLUS) == 1)
    flag = 1;
  return 0;
}

void Adjust(void)
{
  unsigned char t = MyClick();
  if (t == 1) { if (++Menu > 4) Menu = 1; }
  if (t == 2) { Flag_stop = !Flag_stop; if (Flag_stop == 1) { Target = POS_INIT; Position = POS_INIT; } }
  if (t == 3) {
    if (Menu == 1) Balance_KP -= Amp1;
    else if (Menu == 2) Balance_KD -= Amp2;
    else if (Menu == 3) Position_KP -= Amp3;
    else if (Menu == 4) Position_KD -= Amp4;
  }
  if (t == 4) {
    if (Menu == 1) Balance_KP += Amp1;
    else if (Menu == 2) Balance_KD += Amp2;
    else if (Menu == 3) Position_KP += Amp3;
    else if (Menu == 4) Position_KD += Amp4;
  }
  if (Balance_KP < 0) Balance_KP = 0;
  if (Balance_KD < 0) Balance_KD = 0;
  if (Position_KP < 0) Position_KP = 0;
  if (Position_KD < 0) Position_KD = 0;
}

void setup()
{
  Serial.begin(9600);
  delay(1000);
  Serial.println("START");

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(PWM, OUTPUT);
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  analogWrite(PWM, 0);

  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);
  pinMode(KEY_MENU, INPUT_PULLUP);
  pinMode(KEY_S, INPUT_PULLUP);
  pinMode(KEY_MINUS, INPUT_PULLUP);
  pinMode(KEY_PLUS, INPUT_PULLUP);
  pinMode(KEY_X, INPUT_PULLUP);

  attachInterrupt(0, READ_ENC_A, CHANGE);

  // Timer2 CTC: prescaler 1024, count to 78 -> 79*1024/16MHz = 5.056ms (~200Hz)
  TCCR2A = (1 << WGM21);
  TCCR2B = (1 << CS22) | (1 << CS21) | (1 << CS20);
  OCR2A = 78;
  TIMSK2 = (1 << OCIE2A);

  Serial.println("READY");
}

void loop()
{
  Adjust();
  static unsigned long lastT = 0;
  if (millis() - lastT >= 500)
  {
    Serial.print("ADC:"); Serial.print(Sensor);
    Serial.print(" Pos:"); Serial.print(Position);
    Serial.print(" PWM:"); Serial.print(Motor);
    // A/B 为编码器A相(pin2)、B相(pin4)的实时电平: 手动推小车时它们应不停在0/1间跳变,
    // 若始终不变则说明编码器没接线/没信号, Pos 也不会变化
    Serial.print(" A:"); Serial.print(digitalRead(ENC_A));
    Serial.print(" B:"); Serial.print(digitalRead(ENC_B));
    Serial.print(" BKP:"); Serial.print(Balance_KP);
    Serial.print(" BKD:"); Serial.print(Balance_KD);
    Serial.print(" PKP:"); Serial.print(Position_KP);
    Serial.print(" PKD:"); Serial.print(Position_KD);
    Serial.println(Flag_stop == 1 ? " STOP" : " RUN");
    lastT = millis();
  }
}

